from django.contrib import admin
from . models import Customer, Booking, Court, Payment

# Register your models here.
#admin.site.register(Customer)
#admin.site.register(Booking)
#admin.site.register(Court)
#admin.site.register(Payment)

class CustomerAdmin(admin.ModelAdmin):
  list_display = ("name", "email", "phone",)
  
class BookingAdmin(admin.ModelAdmin):
  list_display = ("booking_id", "start_time", "end_time",)

class CourtAdmin(admin.ModelAdmin):
  list_display = ("cost_court", "start_time", "end_time",)

class PaymentAdmin(admin.ModelAdmin):
  list_display = ("payment_id", "customer", "payment_date",)

  
admin.site.register(Customer, CustomerAdmin)
admin.site.register(Booking, BookingAdmin)
admin.site.register(Court, CourtAdmin)
admin.site.register(Payment, PaymentAdmin)