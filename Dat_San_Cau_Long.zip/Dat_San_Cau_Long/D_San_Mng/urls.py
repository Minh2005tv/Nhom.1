from django.urls import path
from . import views

urlpatterns = [
    path('Customer/', views.Customer, name='Customer'),
    path('Booking/', views.Booking, name='Booking'),
    path('Court/', views.Court, name='Court'),
    path('Payment/', views.Payment, name='Payment'),
]